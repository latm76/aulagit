#include <stdio.h>
#include <stdlib.h>

	typedef struct no {
   		struct no *esq;
   		int valor;
   		struct no *dir;
	} tipo_no;


void incluir(int valor, tipo_no **tree)
{
	tipo_no *t,*prox;
 	t = ( tipo_no * ) malloc ( sizeof ( tipo_no ) ) ;
 	t->valor = valor;
 	t->esq = NULL;
 	t->dir = NULL;			
	if (*tree == NULL)
	{
	 	*tree = t;
	}
	else
	{
	//	printf("Teste no raiz: %d\n",(*tree)->valor);
		prox = *tree;
		int bl_incluir=0;
		while (bl_incluir==0)
		{
			if (valor < prox->valor)
			{
				if (prox->esq == NULL)
				{
					prox->esq = t;
					bl_incluir=1;						
				}
				else
				{
					prox = prox->esq;
				}
			}
			else
			{
				if (prox->dir == NULL)
				{
					prox->dir = t;
					bl_incluir=1;
				}
				else
				{
					prox = prox->dir;
				}
			}					
		}
	}
}

void remover(int valor, tipo_no **tree)
{
	tipo_no *t,*prox;
 	t = ( tipo_no * ) malloc ( sizeof ( tipo_no ) ) ;
 	t->valor = valor;
 	t->esq = NULL;
 	t->dir = NULL;			
	if (*tree == NULL)
	{
	 	*tree = t;
	}
	else
	{
	//	printf("Teste no raiz: %d\n",(*tree)->valor);
		prox = *tree;
		int bl_incluir=0;
		while (bl_incluir==0)
		{
			if (valor < prox->valor)
			{
				if (prox->esq == NULL)
				{
					prox->esq = t;
					bl_incluir=1;						
				}
				else
				{
					prox = prox->esq;
				}
			}
			else
			{
				if (prox->dir == NULL)
				{
					prox->dir = t;
					bl_incluir=1;
				}
				else
				{
					prox = prox->dir;
				}
			}					
		}
	}
}

int pesquisar(int valor, tipo_no *ltree)
{
	if (ltree==NULL)
		return 0;
	if (valor==ltree->valor)
	{
		return 1;
	}
	else
	{
		if (valor<ltree->valor)
		{
			return pesquisar(valor,ltree->esq);
		}
		else
		{
			return pesquisar(valor,ltree->dir);
		}
			
	}
}

void listarno(tipo_no *ltree)
{
	
	if (ltree->esq!=NULL)
		listarno(ltree->esq);
	
	printf("%d\n",ltree->valor);

	if (ltree->dir != NULL)
		listarno(ltree->dir);
}

int main()
{
	int i;
	tipo_no *tree = NULL;	
	i = 1;
	while (i != 9)
	{
		printf("1 - Incluir no\n");		
		printf("2 - Remover no\n");
		printf("3 - listar arvore\n");
		printf("4 - pesquisar no\n");		
		printf("9 - sair\n");
		printf("--> ");
		scanf("%d",&i);
		if (i==1)
		{
			int valor;
			printf("valor: ");
			scanf("%d",&valor);
			incluir(valor,&tree);
		}

		if (i==2)
		{
			int valor;
			printf("valor: ");
			scanf("%d",&valor);
			remover(valor,&tree);
		}	
		if (i==3)
		{
			listarno(tree);
		}
		if (i==4)
		{
			int valor, res;
			printf("valor: ");
			scanf("%d",&valor);
			res = pesquisar(valor,tree);
			if (res==0)
				printf("Nao localizado\n");
			else
				printf("localizado\n");
		}					
	}
	return 0;
}

/*
logica
Tree e ponteiro.No endereco de memoria de tree tem-se armazenado o endereco de memoria
do primeiro registro.
Suponha que o endereco de memoria de tree seja A1 e o valor armazenado em A1 seja A2
entao &tree = A1, tree = A2

listarno
ele passa para listarno o valor de tree, ou seja, A2. Em listarno temos que A2 � o
endereco do primeiro registro, ou seja, o valor � armazenado em um ponteiro (*t). 
Ou seja, t aponta A2 e a partir de ent�o os dados sao todos listados.
-->Esta sendo passado um endereco que � um ponteiro para o registro.

incluir
note que para incluirmos um registro devemos alterar o conteudo de A1 (que inicialmente 
� NULL, onde tree aponta). Se passarmos como parametro o conteudo de tree (A2) n�o 
alteraremos A1 (conteudo de tree), fazendo com que tree sempre aponte para NULO.
Logo devemos passar como parametro o endereco de tree (&tree-para podermos alterar tree),
ou seja, A1.
A funcao que recebe tem que entender que esta sendo passado o endereco de um ponteiro,
ou seja, a vari�vel que recebe � um ponteiro de ponteiro (� um endereco para outro endereco)
e por isso **tree.
**tree -> valor tem o valor da n� da arvore
*tree � o conteudo da var�avel A1 que � o endereco A2 (inicialmente � NULL)
*/
