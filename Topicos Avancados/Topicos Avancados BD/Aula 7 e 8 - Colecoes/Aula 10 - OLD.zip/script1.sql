drop table aluno cascade constraints;

Create table aluno (RA number(5),nome varchar2(40), nota1 number(4,2), nota2 number(4,2), nota3 number(4,2), media number(4,2), CONSTRAINT aluno_pk PRIMARY KEY(RA));

insert into aluno (RA,nome,nota1,nota2, nota3) values (1,'Leonardo',8,7,-1);
insert into aluno (RA,nome,nota1,nota2, nota3) values (2,'Andreia',4,3,10);
insert into aluno (RA,nome,nota1,nota2, nota3) values (3,'Ricardo',3,7,2);
insert into aluno (RA,nome,nota1,nota2, nota3) values (4,'Tais',6,6,-1);
insert into aluno (RA,nome,nota1,nota2, nota3) values (5,'Maria',5.5,6.5,-1);
insert into aluno (RA,nome,nota1,nota2, nota3) values (6,'Gilberto',2,4,10);
insert into aluno (RA,nome,nota1,nota2, nota3) values (7,'Adalberto',6,8,-1);
insert into aluno (RA,nome,nota1,nota2, nota3) values (8,'Kaique',9,7,-1);
insert into aluno (RA,nome,nota1,nota2, nota3) values (9,'Monica',10,9.5,-1);
insert into aluno (RA,nome,nota1,nota2, nota3) values (10,'Aline',3,3,3);
insert into aluno (RA,nome,nota1,nota2, nota3) values (11,'Vanusa',4,4,6);
insert into aluno (RA,nome,nota1,nota2, nota3) values (12,'Nilson',3,5,4);
insert into aluno (RA,nome,nota1,nota2, nota3) values (13,'Dener',2,0,4);
insert into aluno (RA,nome,nota1,nota2, nota3) values (14,'Lucas',0,7,7);

commit;

